from flask import render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required
from app.auth import auth_bp
from app.models import User
from app import db
from app.forms import UserForm
from app.utils.decorators import roles_required

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        # Verificación segura usando hash
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('Usuario o contraseña incorrectos')
    
    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


# --- Gestión de usuarios (solo admin) ---
@auth_bp.route('/users')
@login_required
@roles_required('admin')
def users_list():
    usuarios = User.query.order_by(User.username).all()
    return render_template('auth/users.html', users=usuarios)


@auth_bp.route('/users/nuevo', methods=['GET', 'POST'])
@login_required
@roles_required('admin')
def users_create():
    form = UserForm()
    if request.method == 'POST':
        form = UserForm(request.form)
        if form.validate():
            # limit admins to maximum 2
            if form.rol.data == 'admin':
                admin_count = User.query.filter(User.rol.ilike('admin')).count()
                if admin_count >= 2:
                    flash('Ya existen 2 administradores. No se puede crear otro admin.', 'danger')
                    return render_template('auth/user_create.html', form=form)

            if User.query.filter_by(username=form.username.data).first():
                flash('El usuario ya existe', 'danger')
                return render_template('auth/user_create.html', form=form)

            nuevo = User(
                username=form.username.data,
                email=form.email.data,
                nombre_completo=form.nombre_completo.data,
                rol=form.rol.data
            )
            if form.password.data:
                nuevo.set_password(form.password.data)
            else:
                nuevo.set_password('changeme')
            db.session.add(nuevo)
            db.session.commit()
            flash('Usuario creado correctamente', 'success')
            return redirect(url_for('auth.users_list'))
        else:
            for f, errs in form.errors.items():
                for e in errs:
                    flash(f + ': ' + e, 'danger')
    return render_template('auth/user_create.html', form=form)


@auth_bp.route('/users/borrar/<int:id>', methods=['POST'])
@login_required
@roles_required('admin')
def users_delete(id):
    u = User.query.get_or_404(id)
    # prevent deleting last admin or exceed limit rules
    if u.rol and u.rol.lower() == 'admin':
        admin_count = User.query.filter(User.rol.ilike('admin')).count()
        if admin_count <= 1:
            flash('No se puede borrar el último administrador.', 'danger')
            return redirect(url_for('auth.users_list'))
    db.session.delete(u)
    db.session.commit()
    flash('Usuario borrado', 'success')
    return redirect(url_for('auth.users_list'))